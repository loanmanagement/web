


--To create the Loan application Table
1.LoanApplication :
 
 CREATE TABLE LoanApplication(Application_id (auto generated serial no.),application_date(date),
 Loan_program(varchar(10)),AmountofLoan(number),AddressofProperty(varchar(30)),
 AnnualFamilyIncome(number),DocumentProofsAvailable(varchar(50)),GuaranteeCover (varchar(20)),
 MarketValueofGuaranteeCover(number), Status(varchar(10)), DateOfInterview(date));
 
--To create Customer Table
2.CustomerDetails:
 CREATE TABLE CustomerDetails(Application_ID(FK),Applicant_name(varchar(20)),date_of_birth (date),marital_status(varchar(10)),
 phone_number(number), mobile_number(number), CountofDependents(number), email_ id(varchar(20)));
 
--To create Loan programs offered Table
3.LoanProgramsOffered: 
CREATE TABLE LoanProgramsOffered(ProgramName (varchar(5)), description (varchar(20)), type(varchar(00)), durationinyears(number), 
minloanamount(number),maxloanamount(number),rateofinterest(number), proofs_required(varchar(20)));

--To create ApprovedLoans Table
4.ApprovedLoans: 
CREATE TABLE ApprovedLoans(Application_ID(FK), Customer_name(varchar(20),amountofloangranted(number),monthlyinstallment(number),yearstimeperiod(number), 
downpayment(number),rateofinterest(number), totalamountpayable(number)));

--To create Users Table
5.Users : 
CREATE TABLE Users(login_id(varchar(5), password(varchar(10)), role(varchar(5)));
