package com.lms.dao;

import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lms.bean.CustomerDetails;
import com.lms.bean.LoanApplication;
import com.lms.bean.LoanProgramsOffered;
import com.lms.exception.LmsException;

@Repository
@Transactional
public class CustomerDaoImpl implements ICustomerDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public int registerCustomer(CustomerDetails customer) throws LmsException {

		try {
			// entityManager.getTransaction().begin();
			entityManager.persist(customer);
			// entityManager.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();

			throw new LmsException(e.getMessage());
		}
		System.out.println(customer.getDob());

		return customer.getCustomerId();
	}

	@Override
	public int applyLoan(LoanApplication loan, int custId) throws LmsException {

		try {
			CustomerDetails custDetails = entityManager.find(
					CustomerDetails.class, custId);
			
			entityManager.merge(custDetails);
			Date d1 = new java.sql.Date(loan.getApplicationDate().getTime());
			loan.setApplicationDate(d1);
			
			entityManager.persist(loan);
			//loan.getApplicationId();
			custDetails.setApplicationId(loan);

		} catch (Exception e) {
			e.printStackTrace();

			throw new LmsException(e.getMessage());
		}

		return loan.getApplicationId();
	}

	@Override
	public LoanApplication viewApplicationStatus(int applicationId)
			throws LmsException {
      LoanApplication application= entityManager.find(LoanApplication.class, applicationId);
      if(application != null)
		{
    	
			
    	  return application;
		}
			return null;
	}

	@Override
	public List<LoanProgramsOffered> viewAll() throws LmsException {
		List<LoanProgramsOffered> allLoansList;
		try {
			TypedQuery<LoanProgramsOffered> qry = entityManager.createQuery(
					"from LoanProgramsOffered", LoanProgramsOffered.class);

			allLoansList = qry.getResultList();
		} catch (Exception e) {

			throw new LmsException(e.getMessage());
		}

		return allLoansList;
	}

}
