package com.lms.service;

import java.util.List;

import com.lms.bean.CustomerDetails;
import com.lms.bean.LoanApplication;
import com.lms.bean.LoanProgramsOffered;
import com.lms.exception.LmsException;

public interface ICustomerService 
{
	public int registerCustomer(CustomerDetails customer)throws LmsException;
	public int applyLoan( LoanApplication loan, int custId) throws LmsException;
	public LoanApplication viewApplicationStatus(int applicationId) throws LmsException;
	public List<LoanProgramsOffered> viewAll() throws LmsException;
	
}
